import React from "react";
import './App.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rownumberGenerate: [],
      columnnumberGenerate: [],
      colmposition: 0,
      rowposition: 0
    };
  }
  // to get Row number
  getRowNumber(e) {
    try {
      let rowlist = [];
      let i = 0;
      for (i; i < e.target.value; i++) {
        rowlist.push(i);
      }
      this.setState({ rowNumber: rowlist });
    } catch (error) {
      console.log(error);
    }
  }
  // to get coulmn number
  getColumnNumber(e) {
    try {
      let colList = [];
      let j = 0;
      for (j; j < e.target.value; j++) {
        colList.push(j);
      }
      this.setState({ columnnumber: colList });
    } catch (error) {
      console.log(error);
    }
  }

  // generate Dynamic table based on row and column
  getTable() {
    try {
      this.setState({
        tableLoading: true,
        rownumberGenerate: this.state.rowNumber,
        columnnumberGenerate: this.state.columnnumber
      });
    } catch (error) {
      console.log(error);
    }
  }
  // to get column position
  changeColumnPosition(position) {
    try {
      if (position === "bottom") {
        let columncode = this.state.colmposition;
        columncode = columncode + 1;
        if (columncode === this.state.rowNumber.length) {
          columncode = this.state.rowNumber.length - 1;
        }
        this.setState({ colmposition: columncode });
      } else {
        let columncode = this.state.colmposition;
        columncode = columncode - 1;
        if (columncode < 0) {
          columncode = 0;
        }
        this.setState({ colmposition: columncode });
      }
    } catch (error) {
      console.log(error);
    }
  }
  // to get row position
  changeRowPosition(position) {
    try {
      if (position === "right") {
        let columncode = this.state.rowposition;
        columncode = columncode + 1;
        if (columncode === this.state.columnnumber.length) {
          columncode = this.state.columnnumber.length - 1;
        }
        this.setState({ rowposition: columncode });
      } else {
        let columncode = this.state.rowposition;
        columncode = columncode - 1;
        if (columncode < 0) {
          columncode = 0;
        }
        this.setState({ rowposition: columncode });
      }
    } catch (error) {
      console.log(error);
    }
  }
  render() {
    return (
      <div className="col-sm-12">
        <h3 className="mt-2 ml-3">Utthunga Project</h3>
        <div className="col-sm-12 row">
          <div className="col-sm-6 ">
            <input
              type="number"
              className="mt-3  form-control"
              placeholder="Enter Row Number"
              min={"1"}
              onChange={e => this.getRowNumber(e)}
            />
            <br />
            <input
              type="number"
              className="mt-3 form-control"
              placeholder="Enter Column Number"
              min={"1"}
              onChange={e => this.getColumnNumber(e)}
            />
            <br />
            <button
              className="btn btn-primary mt-3"
              onClick={() => this.getTable()}
            >
              Generate
          </button>
          </div>

          <div className="col-sm-6">
            <div className="d-flex p-3 ">
              <div className="p-2">
                <button  className="btn btn-primary font-weight-bold mr-2"  onClick={() => this.changeRowPosition("left")}>Left  </button>
              </div>
         
              <div className="p-2">
                <button  className="btn btn-primary font-weight-bold  mr-2"  onClick={() => this.changeRowPosition("right")}>Right</button>
              </div>
         
              <div className="p-2"> 
               <button className="btn btn-primary font-weight-bold mr-2"  onClick={() => this.changeColumnPosition("top")}>Top </button>
               </div>
               <div className="p-2"> 
               <button className="btn btn-primary font-weight-bold mr-2"  onClick={() => this.changeColumnPosition("bottom")}>Bootom </button>
               </div>
            </div>
          </div>
        </div>
        <div className="col-sm-12 mt-5">
          {this.state.rownumberGenerate !== undefined ? (
            <table class="table table-bordered">
              <tbody>
                {this.state.rownumberGenerate.map((res, index1) => {
                  return (
                    <tr>
                      {this.state.columnnumberGenerate.map((itr, index2) => {
                        return (
                          <td
                            className={
                              index1 === this.state.colmposition &&
                                index2 === this.state.rowposition
                                ? "active"
                                : ""
                            }
                          />
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            ""
          )}
        </div>

      </div>
    );
  }
}

export default App;
